﻿using System;

namespace BankAccountApplication
{
    public class Bank
    {
        public void Transfer(IBankAccount from, IBankAccount to, decimal transferAmount)
        {
            if (from == null || to == null)
            {
                throw new ArgumentException();
            }

            if (transferAmount <= 0.0M)
            {
                throw new InvalidTransactionException();
            }

            if (from.Withdraw(transferAmount))
            {
                to.Deposit(transferAmount);
            }
            else
            {
                throw new InvalidTransactionException();
            }
        }
    }
}